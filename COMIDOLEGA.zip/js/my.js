var div = $(".logo_start");
div.animate({height: '100px', opacity: '0.2'}, "speed");
div.animate({height: '-100px', opacity: '0.3'}, "speed");
div.animate({opacity: '0.4'}, "speed");
div.animate({opacity: '0.5'}, "speed");
div.animate({opacity: '0.6'}, "speed");
div.animate({opacity: '0.7'}, "speed");
div.animate({opacity: '0.8'}, "speed");
div.animate({opacity: '0.9'}, "speed");
div.animate({opacity: '1'}, "slow");

